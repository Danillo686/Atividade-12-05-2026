import { useState, useEffect } from 'react'
import { getPedidos, getClientes, createPedido, updatePedido, deletePedido } from '../services/api'
import { Mensagem } from '../components/Mensagem'
import { Loading } from '../components/Loading'
import '../styles/index.css'

export function Pedidos() {
  const [pedidos, setPedidos] = useState([])
  const [clientes, setClientes] = useState([])
  const [loading, setLoading] = useState(true)
  const [mensagem, setMensagem] = useState(null)
  const [editando, setEditando] = useState(null)
  const [mostrarForm, setMostrarForm] = useState(false)
  const [filtroStatus, setFiltroStatus] = useState('')

  const [formData, setFormData] = useState({
    cliente_id: '',
    descricao: '',
    quantidade: '',
    status: 'pendente'
  })

  const status_opcoes = ['pendente', 'preparando', 'pronto', 'entregue', 'cancelado']

  useEffect(() => {
    carregarDados()
  }, [])

  const carregarDados = async () => {
    try {
      setLoading(true)
      const [pedidosRes, clientesRes] = await Promise.all([
        getPedidos(),
        getClientes()
      ])
      setPedidos(pedidosRes.data)
      setClientes(clientesRes.data)
    } catch (erro) {
      setMensagem({ tipo: 'erro', texto: 'Não foi possível carregar os dados' })
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!formData.cliente_id || !formData.descricao || !formData.quantidade) {
      setMensagem({ tipo: 'aviso', texto: 'Preencha todos os campos' })
      return
    }

    try {
      const dados = {
        cliente_id: parseInt(formData.cliente_id),
        descricao: formData.descricao,
        quantidade: parseInt(formData.quantidade),
        status: formData.status
      }

      if (editando) {
        await updatePedido(editando.id, dados)
        setMensagem({ tipo: 'sucesso', texto: 'Pedido atualizado!' })
      } else {
        await createPedido(dados)
        setMensagem({ tipo: 'sucesso', texto: 'Pedido criado!' })
      }

      setFormData({ cliente_id: '', descricao: '', quantidade: '', status: 'pendente' })
      setEditando(null)
      setMostrarForm(false)
      carregarDados()
    } catch (erro) {
      setMensagem({ tipo: 'erro', texto: 'Erro ao salvar pedido' })
    }
  }

  const handleEditar = (pedido) => {
    setEditando(pedido)
    setFormData({
      cliente_id: pedido.cliente_id,
      descricao: pedido.descricao,
      quantidade: pedido.quantidade,
      status: pedido.status
    })
    setMostrarForm(true)
  }

  const handleCancelar = () => {
    setEditando(null)
    setFormData({ cliente_id: '', descricao: '', quantidade: '', status: 'pendente' })
    setMostrarForm(false)
  }

  const handleExcluir = async (id) => {
    if (confirm('Tem certeza que deseja excluir?')) {
      try {
        await deletePedido(id)
        setMensagem({ tipo: 'sucesso', texto: 'Pedido removido!' })
        carregarDados()
      } catch (erro) {
        setMensagem({ tipo: 'erro', texto: 'Erro ao remover pedido' })
      }
    }
  }

  const getNomeCliente = (clienteId) => {
    const cliente = clientes.find(c => c.id === clienteId)
    return cliente ? cliente.nome : 'Cliente não encontrado'
  }

  const pedidosFiltrados = filtroStatus 
    ? pedidos.filter(p => p.status === filtroStatus)
    : pedidos

  if (loading) return <Loading />

  return (
    <div className="pedidos">
      <div className="container">
        <div className="header-page">
          <h1>Pedidos</h1>
          <button 
            className="btn btn-primary"
            onClick={() => setMostrarForm(!mostrarForm)}
          >
            + Novo Pedido
          </button>
        </div>

        {mensagem && (
          <Mensagem 
            tipo={mensagem.tipo}
            texto={mensagem.texto}
            onClose={() => setMensagem(null)}
          />
        )}

        <div className="filtros">
          <label>Filtrar por status:</label>
          <select 
            value={filtroStatus}
            onChange={(e) => setFiltroStatus(e.target.value)}
            className="select"
          >
            <option value="">Todos</option>
            {status_opcoes.map(s => (
              <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>
            ))}
          </select>
        </div>

        {mostrarForm && (
          <form className="form" onSubmit={handleSubmit}>
            <div className="form-row">
              <div className="form-group">
                <label>Cliente</label>
                <select
                  value={formData.cliente_id}
                  onChange={(e) => setFormData({ ...formData, cliente_id: e.target.value })}
                  className="select"
                >
                  <option value="">Selecione um cliente</option>
                  {clientes.map(cliente => (
                    <option key={cliente.id} value={cliente.id}>
                      {cliente.nome}
                    </option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label>Status</label>
                <select
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                  className="select"
                >
                  {status_opcoes.map(s => (
                    <option key={s} value={s}>
                      {s.charAt(0).toUpperCase() + s.slice(1)}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="form-group">
              <label>Descrição</label>
              <textarea
                value={formData.descricao}
                onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                rows="3"
              ></textarea>
            </div>

            <div className="form-group">
              <label>Quantidade</label>
              <input
                type="number"
                value={formData.quantidade}
                onChange={(e) => setFormData({ ...formData, quantidade: e.target.value })}
                min="1"
              />
            </div>

            <div className="form-actions">
              <button type="submit" className="btn btn-primary">
                {editando ? 'Atualizar' : 'Criar'}
              </button>
              <button type="button" className="btn btn-secondary" onClick={handleCancelar}>
                Cancelar
              </button>
            </div>
          </form>
        )}

        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th>Cliente</th>
                <th>Descrição</th>
                <th>Quantidade</th>
                <th>Status</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody>
              {pedidosFiltrados.length === 0 ? (
                <tr>
                  <td colSpan="5" className="text-center">Nenhum pedido encontrado</td>
                </tr>
              ) : (
                pedidosFiltrados.map(pedido => (
                  <tr key={pedido.id}>
                    <td>{getNomeCliente(pedido.cliente_id)}</td>
                    <td>{pedido.descricao}</td>
                    <td>{pedido.quantidade}</td>
                    <td>
                      <span className={`badge badge-${pedido.status}`}>
                        {pedido.status.charAt(0).toUpperCase() + pedido.status.slice(1)}
                      </span>
                    </td>
                    <td className="acoes">
                      <button 
                        className="btn btn-small btn-edit"
                        onClick={() => handleEditar(pedido)}
                      >
                        Editar
                      </button>
                      <button 
                        className="btn btn-small btn-delete"
                        onClick={() => handleExcluir(pedido.id)}
                      >
                        Excluir
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
