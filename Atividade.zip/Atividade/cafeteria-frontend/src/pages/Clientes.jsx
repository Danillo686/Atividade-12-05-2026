import { useState, useEffect } from 'react'
import { getClientes, createCliente, updateCliente, deleteCliente } from '../services/api'
import { Mensagem } from '../components/Mensagem'
import { Loading } from '../components/Loading'
import '../styles/index.css'

export function Clientes() {
  const [clientes, setClientes] = useState([])
  const [loading, setLoading] = useState(true)
  const [mensagem, setMensagem] = useState(null)
  const [editando, setEditando] = useState(null)
  const [mostrarForm, setMostrarForm] = useState(false)
  
  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    telefone: ''
  })

  useEffect(() => {
    carregarClientes()
  }, [])

  const carregarClientes = async () => {
    try {
      setLoading(true)
      const response = await getClientes()
      setClientes(response.data)
    } catch (erro) {
      setMensagem({ tipo: 'erro', texto: 'Não foi possível carregar os clientes' })
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!formData.nome || !formData.email || !formData.telefone) {
      setMensagem({ tipo: 'aviso', texto: 'Preencha todos os campos' })
      return
    }

    try {
      if (editando) {
        await updateCliente(editando.id, formData)
        setMensagem({ tipo: 'sucesso', texto: 'Cliente atualizado!' })
      } else {
        await createCliente(formData)
        setMensagem({ tipo: 'sucesso', texto: 'Cliente cadastrado!' })
      }
      
      setFormData({ nome: '', email: '', telefone: '' })
      setEditando(null)
      setMostrarForm(false)
      carregarClientes()
    } catch (erro) {
      setMensagem({ tipo: 'erro', texto: 'Erro ao salvar cliente' })
    }
  }

  const handleEditar = (cliente) => {
    setEditando(cliente)
    setFormData(cliente)
    setMostrarForm(true)
  }

  const handleCancelar = () => {
    setEditando(null)
    setFormData({ nome: '', email: '', telefone: '' })
    setMostrarForm(false)
  }

  const handleExcluir = async (id) => {
    if (confirm('Tem certeza que deseja excluir?')) {
      try {
        await deleteCliente(id)
        setMensagem({ tipo: 'sucesso', texto: 'Cliente removido!' })
        carregarClientes()
      } catch (erro) {
        setMensagem({ tipo: 'erro', texto: 'Erro ao remover cliente' })
      }
    }
  }

  if (loading) return <Loading />

  return (
    <div className="clientes">
      <div className="container">
        <div className="header-page">
          <h1>Clientes</h1>
          <button 
            className="btn btn-primary"
            onClick={() => setMostrarForm(!mostrarForm)}
          >
            + Novo Cliente
          </button>
        </div>

        {mensagem && (
          <Mensagem 
            tipo={mensagem.tipo}
            texto={mensagem.texto}
            onClose={() => setMensagem(null)}
          />
        )}

        {mostrarForm && (
          <form className="form" onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Nome</label>
              <input
                type="text"
                value={formData.nome}
                onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
              />
            </div>

            <div className="form-group">
              <label>Email</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
            </div>

            <div className="form-group">
              <label>Telefone</label>
              <input
                type="tel"
                value={formData.telefone}
                onChange={(e) => setFormData({ ...formData, telefone: e.target.value })}
              />
            </div>

            <div className="form-actions">
              <button type="submit" className="btn btn-primary">
                {editando ? 'Atualizar' : 'Cadastrar'}
              </button>
              <button type="button" className="btn btn-secondary" onClick={handleCancelar}>
                Cancelar
              </button>
            </div>
          </form>
        )}

        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th>Nome</th>
                <th>Email</th>
                <th>Telefone</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody>
              {clientes.length === 0 ? (
                <tr>
                  <td colSpan="4" className="text-center">Nenhum cliente encontrado</td>
                </tr>
              ) : (
                clientes.map(cliente => (
                  <tr key={cliente.id}>
                    <td>{cliente.nome}</td>
                    <td>{cliente.email}</td>
                    <td>{cliente.telefone}</td>
                    <td className="acoes">
                      <button 
                        className="btn btn-small btn-edit"
                        onClick={() => handleEditar(cliente)}
                      >
                        Editar
                      </button>
                      <button 
                        className="btn btn-small btn-delete"
                        onClick={() => handleExcluir(cliente.id)}
                      >
                        Excluir
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
