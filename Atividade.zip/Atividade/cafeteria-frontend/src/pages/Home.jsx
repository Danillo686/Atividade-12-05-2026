import { Link } from 'react-router-dom'
import '../styles/index.css'

export function Home() {
  return (
    <div className="page">
      <div className="container">
        <h1>Bem-vindo à Cafeteria</h1>
        <p>Um sistema simples para cadastrar clientes e criar pedidos.</p>
        <div className="home-actions">
          <Link className="btn" to="/clientes">Clientes</Link>
          <Link className="btn btn-secondary" to="/pedidos">Pedidos</Link>
        </div>
      </div>
    </div>
  )
}
