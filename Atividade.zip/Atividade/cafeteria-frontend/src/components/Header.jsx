import { Link } from 'react-router-dom'
import '../styles/index.css'

export function Header() {
  return (
    <header className="header">
      <div className="container header-inner">
        <div className="brand">Cafeteria</div>
        <nav className="nav">
          <Link to="/">Home</Link>
          <Link to="/clientes">Clientes</Link>
          <Link to="/pedidos">Pedidos</Link>
        </nav>
      </div>
    </header>
  )
}
