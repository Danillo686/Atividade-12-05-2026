import '../styles/mensagem.css'

export function Mensagem({ tipo, texto, onClose }) {
  return (
    <div className={`mensagem mensagem-${tipo}`}>
      <span>{texto}</span>
      <button onClick={onClose}>✕</button>
    </div>
  )
}
